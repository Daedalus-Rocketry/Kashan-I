src/main.o: src/main.c include/main.h include/DataConst.h \
 include/state_vectors.h include/DataConst.h include/state_vectors.h \
 include/timers.h include/version.h
