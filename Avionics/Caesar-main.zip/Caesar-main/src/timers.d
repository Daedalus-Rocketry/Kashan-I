src/timers.o: src/timers.c include/timers.h
