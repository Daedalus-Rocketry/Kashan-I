#include "timers.h"
#include <stdio.h>

void init_timer(Timer *timer) {
    gettimeofday(&timer->start_time, NULL);
    timer->pause_time = timer->start_time;
    timer->paused = 0;
    timer->counting_up = 0;
}

void init_timer_with_start(Timer *timer, time_t start_seconds, suseconds_t start_microseconds) {
    timer->start_time.tv_sec = start_seconds;
    timer->start_time.tv_usec = start_microseconds;
    timer->pause_time = timer->start_time;
    timer->paused = 1; // Metti in pausa all'inizio per il conto alla rovescia
    timer->counting_up = 0;
}

void start_timer(Timer *timer) {
    gettimeofday(&timer->start_time, NULL);
    timer->pause_time = timer->start_time;
    timer->paused = 0;
}

void pause_timer(Timer *timer) {
    if (!timer->paused) {
        gettimeofday(&timer->pause_time, NULL);
        timer->paused = 1;
    }
}

void resume_timer(Timer *timer) {
    if (timer->paused) {
        struct timeval current_time;
        gettimeofday(&current_time, NULL);

        timersub(&current_time, &timer->pause_time, &timer->start_time);
        timer->paused = 0;
    }
}

double get_elapsed_time(Timer *timer) {
    struct timeval current_time;

    if (timer->paused) {
        timersub(&timer->pause_time, &timer->start_time, &current_time);
    } else {
        gettimeofday(&current_time, NULL);
        timersub(&current_time, &timer->start_time, &current_time);
    }

    return (current_time.tv_sec * 1000.0) + (current_time.tv_usec / 1000.0);
}