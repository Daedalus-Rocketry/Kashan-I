/************************************************************************************\
 *                                                                                   *
 *       Sistema di Guida e navigazione Caesar v1.0                                  *
 *                                                                                   *
 *       FILE MAIN.C                                                                 *
 *                                                                                   *
 *       Copyright 2023 Com. Francesco Cesare Giorgio Teseo Bosatra                  *
 *                                                                                   *
 *                                                                                   *
\************************************************************************************/

#include <stdio.h>
#include <math.h>
#include "main.h"
#include "DataConst.h"
#include "state_vectors.h"
#include "timers.h"
#include "version.h"

state_t flight_state = STATE_INIT;
StateVector rocket;
Timer SysTime, GET, MET;

int main()
{

    printf("Caesar %s In Avvio \n", VERSION);

    init();
    menu();

    int met_started = 1;
    int met_zero = 1;

    while (1)
    {

        switch (flight_state)
        {
        case STATE_INIT:
            /* code */
            break;

        default:
            break;
        }

        // printf("SysTime: %f\tGET: %f\tMET: %f\n", get_elapsed_time(&SysTime), get_elapsed_time(&GET), get_elapsed_time(&MET));
    }

    return 0;
}

void init()
{
    printf("Caesar Init");
    init_timer(&SysTime);
    start_timer(&SysTime);

    // Inizializza MET a -5 secondi in pausa
    init_timer_with_start(&MET, -5, 0);
    pause_timer(&MET);

    init_timer(&GET);
    pause_timer(&GET);

    double initPos[3] = {0, 0, 0};
    double initVel[3] = {0, 0, 0};
    double initOrient[3] = {0, 0, 0};
    rocket = createStateVectors(initPos, initVel, initOrient, 3, 4, 0);
}

void menu()
{

    do
    {
        printf("Selezionare un opzione: \nl) ordine di lancio\ns) ordine di scrub\ne) Uscita dal sistema\n\n");
        char c = getchar();
        switch (c)
        {
        case 'l':
        case 'L':
            countdown();
            return;

        case 's':
        case 'S':
            abort(flight_state, &rocket, "Scrub in rampa");
            return;
        case 'e':
        case 'E':
            exit(0);

        default:
            break;
        }
    } while (1);
}
void countdown()
{
    printf("Seleziona un tempo in secondi al lancio: [sec]\n");
    int sec;
    scanf("%d", &sec);
    getchar();

    printf("%d", sec);
    MET.start_time.tv_sec -= sec;
    MET.start_time.tv_usec = 0;
    MET.counting_up = 1;
    start_timer(&MET);
    printf("MET %.2f", get_elapsed_time(&MET));
}

void liftoff()
{
    start_timer(&GET);
}

void landed()
{
    pause_timer(&GET);
}

void Vale(state_t state, StateVector *rocket, char *dettagli)
{
    printf("ABORT Sys[%.2f]\tMET[%.2f]\tGET[%.2f]\n", get_elapsed_time(&SysTime), get_elapsed_time(&MET), get_elapsed_time(&GET));
    printf("ABORT Flight State: %d\n", state);
    printf("ABORT State Vectors:\n");
    printf("ABORT posx\tposy\tposz\tvelx\tvely\tvelz\ttheta\tgamma\tomega\tmassa\talt\tengine\taccx\taccy\taccz\tradx\trady\tradz\n\n");
    printf("ABORT %f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%d\t%f\t%f\t%f\t%f\t%f\t%f\n");
    if (rocket->altitude > 100 || dettagli == "AbortTest")
    {
        pyro_arm();
        secs_logic_Up();
        explode(&rocket);
    }
    else
    {
        pyro_disarm();
        secs_logic_down();
        isolate_power(&rocket)
    }

    exit(1);
}
