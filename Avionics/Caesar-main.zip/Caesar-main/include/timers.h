#ifndef TIMER_H
#define TIMER_H

#include <sys/time.h>

typedef struct {
    struct timeval start_time;
    struct timeval pause_time;
    int paused;
    int counting_up;
} Timer;

void init_timer(Timer *timer);
void init_timer_with_start(Timer *timer, time_t start_seconds, suseconds_t start_microseconds);
void start_timer(Timer *timer);
void pause_timer(Timer *timer);
void resume_timer(Timer *timer);
double get_elapsed_time(Timer *timer);

#endif /* TIMER_H */