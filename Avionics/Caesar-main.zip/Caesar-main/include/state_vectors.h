/************************************************************************************\
 *          ______     ___       _______     _______.     ___      .______          *
 *         /      |   /   \     |   ____|   /       |    /   \     |   _  \         *
 *        |  ,----'  /  ^  \    |  |__     |   (----`   /  ^  \    |  |_)  |        *
 *        |  |      /  /_\  \   |   __|     \   \      /  /_\  \   |      /         *
 *        |  `----./  _____  \  |  |____.----)   |    /  _____  \  |  |\  \----.    *
 *        \______/__/     \__\ |_______|_______/    /__/     \__\ | _| `._____|     *
 *                                                                                  *
 *         __      ___                                                              *
 *        /_ |    / _ \                                                             *
 *        | |    | | | |                                                            *
 *        | |    | | | |                                                            *
 *        | |  __| |_| |                                                            *
 *        |_| (__)\___/                                                             *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *       Sistema di Guida e navigazione Caesar v1.0                                 *
 *                                                                                  *
 *       FILE STATE_VECTORS.H                                                       *
 *                                                                                  *
 *       Copyright 2023 Com. Francesco Cesare Giorgio Teseo Bosatra                 *
 *                                                                                  *
 *                                                                                  *
\************************************************************************************/

#ifndef STATE_VECTORS_H
#define STATE_VECTORS_H

typedef struct
{
    double position[3];
    double velocity[3];
    double orientation[3];
    double initial_mass;
    double mass;
    double fuel_mass;
    double altitude;
    int engine_on;
    double accelerations[3];      // Accelerazioni lungo gli assi x, y, z
    double angular_velocities[3]; // Velocità angolari intorno agli assi x, y, z

} StateVector;

StateVector createStateVectors(double initialPosition[3], double initialVelocity[3], double initialOrientation[3], double initialMass, double initialFuelMass, double initialAltitude);

void updateStateVectors(StateVector *rocket, double dt, double accelerations[3], double angularVelocities[3], double barometricAltitude, double engineRuntime);

double controlloApA(StateVector rocket, double dt, double accelerations[3], double rotations[3], double barometricAltitude, double engineRuntime);

void predictStateVector(StateVector *rocket, double dt);

#endif /* STATE_VECTORS_H */