/************************************************************************************\
 *          ______     ___       _______     _______.     ___      .______          *
 *         /      |   /   \     |   ____|   /       |    /   \     |   _  \         *
 *        |  ,----'  /  ^  \    |  |__     |   (----`   /  ^  \    |  |_)  |        *
 *        |  |      /  /_\  \   |   __|     \   \      /  /_\  \   |      /         *
 *        |  `----./  _____  \  |  |____.----)   |    /  _____  \  |  |\  \----.    *
 *        \______/__/     \__\ |_______|_______/    /__/     \__\ | _| `._____|     *
 *                                                                                  *
 *         __      ___                                                              *
 *        /_ |    / _ \                                                             *
 *        | |    | | | |                                                            *
 *        | |    | | | |                                                            *
 *        | |  __| |_| |                                                            *
 *        |_| (__)\___/                                                             *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *       Sistema di Guida e navigazione Caesar v1.0                                 *
 *                                                                                  *
 *       FILE DATACONST.H                                                           *
 *                                                                                  *
 *       Copyright 2023 Com. Francesco Cesare Giorgio Teseo Bosatra                 *
 *                                                                                  *
 *                                                                                  *
\************************************************************************************/
#ifndef DATACONST_H
#define DATACONST_H

typedef enum
{
    STATE_INIT,
    STATE_FLIGHT_PRE_MECO,
    STATE_FLIGHT_POST_MECO,
    STATE_DESCENT,
    STATE_LANDED
} state_t;

typedef enum
{
    DATA_OK,
    DATA_PARTIAL,
    DATA_DEGRADED
} data_t;

const float DELTAACCELRAZIONE = 0.0f;
const float DELTAROTAZIONI = 0.0f;
const float DELTAALTITUDINE = 0.0f;

#endif /*DATACONST_H*/
