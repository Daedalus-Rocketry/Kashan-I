/************************************************************************************\
 *          ______     ___       _______     _______.     ___      .______          *
 *         /      |   /   \     |   ____|   /       |    /   \     |   _  \         *
 *        |  ,----'  /  ^  \    |  |__     |   (----`   /  ^  \    |  |_)  |        *
 *        |  |      /  /_\  \   |   __|     \   \      /  /_\  \   |      /         *
 *        |  `----./  _____  \  |  |____.----)   |    /  _____  \  |  |\  \----.    *
 *        \______/__/     \__\ |_______|_______/    /__/     \__\ | _| `._____|     *
 *                                                                                  *
 *         __      ___                                                              *
 *        /_ |    / _ \                                                             *
 *        | |    | | | |                                                            *
 *        | |    | | | |                                                            *
 *        | |  __| |_| |                                                            *
 *        |_| (__)\___/                                                             *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *                                                                                  *
 *       Sistema di Guida e navigazione Caesar v1.0                                 *
 *                                                                                  *
 *       FILE MAIN.H                                                                *
 *                                                                                  *
 *       Copyright 2023 Com. Francesco Cesare Giorgio Teseo Bosatra                 *
 *                                                                                  *
 *                                                                                  *
\************************************************************************************/
#ifndef MAIN_H
#define MAIN_H

#include "DataConst.h"
#include "state_vectors.h"

void countdown();

void init();

void liftoff();

void meco();

void apogee();

void landed();

void loop(float acc_x, float acc_y, float acc_z, float gyro_x, float gyro_y,
          float gyro_z, float baro);

void menu();

void abort(state_t state, StateVector *rocket, char *dettagli);
#endif /*MAIN_H*/